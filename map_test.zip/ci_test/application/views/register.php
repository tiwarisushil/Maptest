<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
   Register
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="<?php echo base_url('assets/css/material-dashboard.css?v=2.1.2');?>" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php echo base_url('assets/demo/demo.css')?>" rel="stylesheet" />

</head>
<body>

	 <div class="wrapper ">
	 	  <?php

        if($this->session->flashdata('error'))
        {
          echo '<div class="row mt-2">
              <div class="col-md-6 mx-auto">
                <div class="alert alert-danger">';
          
          echo $this->session->flashdata('error');
          
          echo  '</div>
              </div>
          </div>';
        }


           	$attribute = array('id' =>'login_form');

           	 echo form_open('register',$attribute);?>


	 	     <div class="row">
         
           <div class="col-md-6 mx-auto">
           		<div class="card">
           			<div class="card-body">
           				<div class="row">
                    <div class="col-12 form-group mb-3">
                      <label>First Name</label>
                      <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" class="form-control">
                    </div>
                     <div class="col-12 form-group mb-3">
                      <label>Last Name</label>
                      <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" class="form-control">
                    </div>
           					<div class="col-12 form-group mb-3">
           						<label>Email</label>
           						<input type="email" name="email" value="<?php echo set_value('email'); ?>" class="form-control">
           					</div>
                    <div class="col-12 form-group mb-3">
                      <label>Contact</label>
                      <input type="text" name="contact" value="<?php echo set_value('contact'); ?>" class="form-control" maxlength="10" >
                    </div>
           					<div class="col-12 form-group mb-3">
           						<label>Password</label>
           						<input type="password" name="password" class="form-control">
           					</div>
                    <div class="col-12 form-group mb-3">
                      <label>Confirm Password</label>
                      <input type="password" name="cpassword" class="form-control">
                    </div>
           				</div>
           				<div class="row">
           					<div class="col-12 d-flex justify-content-center">
           						<button type="submit" class="btn btn-primary">Login</button>
           					</div>
           				</div>
           			</div>
           		</div>

            <div class="text-muted text-center">Already Registered? <a href="<?php echo base_url('login');?>">Login Here</a></div>
           </div>
           
          </div>
          </form>
	 </div>



 <!--   Core JS Files   -->
  <script src="<?php echo base_url('');?>assets/js/core/jquery.min.js"></script>
  <script src="<?php echo base_url('');?>assets/js/core/popper.min.js"></script>
  <script src="<?php echo base_url('');?>assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="<?php echo base_url('');?>assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
</body>
</html>