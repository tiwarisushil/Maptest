<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

 	public function __construct()
    {
        parent::__construct();
        // Your own constructor code
        if($this->session->userdata('is_logged_in')!=TRUE)
        {
        	redirect('logout','refresh');
        }

        $this->load->model(array('AuthModel'=>'auth'));
    }

    public function index($page = 'dashboard',$data = array())
    {
    	$this->load->view('Layout/header');
    	$this->load->view('Layout/JS');
    	$this->load->view($page,$data);

    	$this->load->view('Layout/footer');
    }
}