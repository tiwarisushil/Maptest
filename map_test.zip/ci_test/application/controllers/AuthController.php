<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AuthController extends CI_Controller {

 	public function __construct()
    {
        parent::__construct();
        // Your own constructor code

        $this->load->model(array('AuthModel'=>'auth'));
    }
	public function login()
	{
		if($this->input->post(null,true))
		{
			$this->form_validation->set_rules('email','Email','required|valid_email');
			$this->form_validation->set_rules('password','Password','required|min_length[5]');
			if($this->form_validation->run() ==FALSE)
			{
				$this->load->view('login');
			}
			else
			{
				$password = $this->input->post('password');
				$data = $this->auth->validateLogin();
				if(!empty($data))
				{
					if(password_verify($password, $data->password))
					{
						$new_data = array(
									'userID'=>$data->id,
									'name'=>$data->firstname.' '.$data->lastname,
									'email'=>$data->email,
									'mobile'=>$data->mobile,
									'is_logged_in'=>true
								);
						$this->session->set_userdata($new_data);

						// echo '<pre>';
						// print_r($this->session->userdata());
						// echo '</pre>';
						redirect('user','refresh');
					}
					else
					{
						$this->session->set_flashdata('error','Wrong Password');
						$this->load->view('login');
					}
				}
				else
				{
					$this->session->set_flashdata('error','Invalid Email Provided');
					$this->load->view('login');
				}
			}
		}
		else{
				$this->load->view('login');
		}
	
	}
	public function register()
	{
		if($this->input->post(null,true))
		{
			$this->form_validation->set_rules('firstname','Firstname','required|min_length[3]');
			$this->form_validation->set_rules('lastname','Lastname','required|min_length[3]');
			$this->form_validation->set_rules('email','Email','required|valid_email|is_unique[users.email]');
			$this->form_validation->set_rules('contact','Contact','required|integer|min_length[10]|max_length[10]|is_unique[users.mobile]');
			$this->form_validation->set_rules('password','Password','required|min_length[5]');
			$this->form_validation->set_rules('cpassword','Confirm Password','required|min_length[5]|matches[password]');

			if($this->form_validation->run() == FALSE)
			{
				$this->session->set_flashdata('error',validation_errors());
				$this->load->view('register');
			}
			else
			{
				$output = $this->auth->registerUser();
				if($output ==true)
				{
					$this->session->set_flashdata('message','You are registered successfully');
					$this->load->view('login');
				}
			}
		}
		else
		{
			$this->load->view('register');
		}
		// 
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login','refresh');
	}
}
