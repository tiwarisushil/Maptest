<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-12 12:49:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth D:\xampp\htdocs\ci_test\system\core\Loader.php 348
ERROR - 2020-06-12 13:00:31 --> Severity: error --> Exception: Call to undefined method AuthController::form_validation() D:\xampp\htdocs\ci_test\application\controllers\AuthController.php 17
ERROR - 2020-06-12 13:22:19 --> Severity: error --> Exception: Call to undefined method AuthModel::insert() D:\xampp\htdocs\ci_test\application\models\AuthModel.php 23
ERROR - 2020-06-12 13:34:51 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::seelct() D:\xampp\htdocs\ci_test\application\models\AuthModel.php 8
ERROR - 2020-06-12 13:39:32 --> 404 Page Not Found: Logout/index
ERROR - 2020-06-12 13:40:08 --> Severity: error --> Exception: Call to undefined method CI_Session::destroy() D:\xampp\htdocs\ci_test\application\controllers\AuthController.php 97
ERROR - 2020-06-12 13:44:47 --> 404 Page Not Found: User/index
ERROR - 2020-06-12 13:45:19 --> Severity: error --> Exception: syntax error, unexpected '{', expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\ci_test\application\controllers\UserController.php 19
ERROR - 2020-06-12 13:46:12 --> 404 Page Not Found: UserController/index
ERROR - 2020-06-12 13:46:31 --> Severity: error --> Exception: Too few arguments to function UserController::index(), 0 passed in D:\xampp\htdocs\ci_test\system\core\CodeIgniter.php on line 532 and exactly 2 expected D:\xampp\htdocs\ci_test\application\controllers\UserController.php 18
ERROR - 2020-06-12 14:05:57 --> 404 Page Not Found: Assets/leaftlet
ERROR - 2020-06-12 14:06:23 --> 404 Page Not Found: Assets/leaftlet
ERROR - 2020-06-12 14:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-12 14:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-12 14:20:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-12 14:21:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-12 14:23:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-12 14:56:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 14:56:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 14:56:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 14:57:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 14:58:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:00:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:00:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:00:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-12 15:01:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:02:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:03:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:03:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:03:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:03:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:31:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:31:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:31:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:37:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:37:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:37:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:39:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:40:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:40:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:41:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:41:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:41:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:41:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:42:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:42:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:43:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:44:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:44:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:44:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:45:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:45:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:46:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:46:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:47:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:47:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:48:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:48:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:49:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 15:51:57 --> 404 Page Not Found: Assets/images
