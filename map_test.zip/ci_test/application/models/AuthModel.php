<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AuthModel extends CI_Model {

	function validateLogin()
	{
		$query = $this->db->select('*')
					->from('users')
					->where('email',$this->input->post('email'))
					->get();

		if($query->num_rows()>0)
		{
			return $query->row();
		}

	}

	function registerUser()
	{
		$password = password_hash($this->input->post('password',true), PASSWORD_BCRYPT) ;

		$obj = array('firstname'=>$this->input->post('firstname',true),
					'lastname'=>$this->input->post('lastname',true),
					'email' => $this->input->post('email',true),
					'mobile'=> $this->input->post('contact',true),
					'password'=>$password,
					'is_active'=>1,
					'created_at'=>date('Y-m-d H:i:s'),
				);
		$this->db->insert('users',$obj);
		if($this->db->affected_rows()>0)
		{
			return true;
		}
	}

}